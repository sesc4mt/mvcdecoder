//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by YUVviewer.rc
//
#define IDCLOSEALL                      3
#define IDC_TRANSFER                    4
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_YUVVIEWER_DIALOG            102
#define IDR_MAINFRAME                   128
#define IDC_SIZE_CIF                    1000
#define IDC_SIZE_QCIF                   1001
#define IDC_SIZE_OTHER                  1002
#define IDC_SIZE_WIDTH                  1003
#define IDC_SIZE_HEIGHT                 1004
#define IDC_FRAME_RATE                  1005
#define IDC_FRAME_FROM                  1007
#define IDC_FRAME_TO                    1008
#define IDC_OPENFILE                    1009
#define IDC_PAUSEPLAY                   1010
#define IDC_NEXT                        1011
#define IDC_PREVIOUS                    1012
#define IDC_STATIC_W                    1013
#define IDC_STATIC_H                    1014
#define IDC_ORDER                       1015
#define IDC_NEXT5                       1016
#define IDC_PREVIOUS5                   1017
#define IDC_ZOOM                        1018

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        131
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1019
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
