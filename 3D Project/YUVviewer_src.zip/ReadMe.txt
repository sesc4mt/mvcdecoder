
This is a software piece to view and compare raw YUV sequences. It's so simple
therefore no need to have a help. Currently it can open 36 windows, therefore
display 36 YUV sequences, at one time. You can modify the source code to support
more, but maybe not neccessary.

It reserves many places for improvements. The authors are appreciated if you
would like to share your improvements.

Thanks are expressed to Dagmar Geske and Henrik Thuermer, for the file cscc.lib
and its header file Convert.h were authored by them. These files were originally 
public in the Internet. I even cannot remember when and where I downloaded them.


/************************************************************************
 *
 *  Ye-Kui Wang       wyk@ieee.org
 *  Juan-Juan Jiang   juanjuan_j@hotmail.com
 *  
 *  March 14, 2002
 *
 ************************************************************************/

/*
 * Disclaimer of Warranty
 *
 * These software programs are available to the user without any
 * license fee or royalty on an "as is" basis.  The developers disclaim 
 * any and all warranties, whether express, implied, or statuary, including 
 * any implied warranties or merchantability or of fitness for a particular 
 * purpose.  In no event shall the copyright-holder be liable for any incidental,
 * punitive, or consequential damages of any kind whatsoever arising from 
 * the use of these programs.
 *
 * This disclaimer of warranty extends to the user of these programs
 * and user's customers, employees, agents, transferees, successors,
 * and assigns.
 *
 * The developers does not represent or warrant that the programs furnished 
 * hereunder are free of infringement of any third-party patents.
 *
 * */

