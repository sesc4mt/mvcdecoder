
/*!
***************************************************************************
*
* \file symbol.c
*
* \brief
*    Generic Symbol writing interface
*
* \date
*    18 Jan 2006
*
* \author
*    Karsten Suehring   suehring@hhi.de
**************************************************************************/

#include "global.h"
#include "symbol.h"
