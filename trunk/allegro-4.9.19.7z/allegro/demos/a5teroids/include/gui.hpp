#ifndef GUI_HPP
#define GUI_HPP

int do_menu(void);

#endif // GUI_HPP

