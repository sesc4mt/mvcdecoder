#ifndef DEBUG_H
#define DEBUG_H

#include "a5teroids.hpp"

void debug_message(const std::string&, ...);

#endif

