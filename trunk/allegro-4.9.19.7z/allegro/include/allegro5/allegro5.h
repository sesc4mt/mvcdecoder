#ifndef ALLEGRO5_H
#define ALLEGRO5_H

#include "allegro.h"

#endif

