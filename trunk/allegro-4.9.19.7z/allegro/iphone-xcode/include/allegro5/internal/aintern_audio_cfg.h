/*
 * OpenAL did not seem to work well at all when I used it on
 * iPhone so this is commented out for now.
#define ALLEGRO_CFG_KCM_OPENAL
 */
#define ALLEGRO_CFG_KCM_AQUEUE
